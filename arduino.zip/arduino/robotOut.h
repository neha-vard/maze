#ifndef ROBOTOUT_H_
#define ROBOTOUT_H_

#include "common.h"

void dropKit();

#endif
